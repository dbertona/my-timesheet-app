import{R as e,r as t}from"./react-CIBlej6S.js";var r={color:void 0,size:void 0,className:void 0,style:void 0,attr:void 0},a=e.createContext&&e.createContext(r),o=["attr","size","title"];function i(e,t){if(null==e)return{};var r,a,o=function(e,t){if(null==e)return{};var r={};for(var a in e)if(Object.prototype.hasOwnProperty.call(e,a)){if(t.indexOf(a)>=0)continue;r[a]=e[a]}return r}(e,t);if(Object.getOwnPropertySymbols){var i=Object.getOwnPropertySymbols(e);for(a=0;a<i.length;a++)r=i[a],t.indexOf(r)>=0||Object.prototype.propertyIsEnumerable.call(e,r)&&(o[r]=e[r])}return o}function s(){return s=Object.assign?Object.assign.bind():function(e){for(var t=1;t<arguments.length;t++){var r=arguments[t];for(var a in r)Object.prototype.hasOwnProperty.call(r,a)&&(e[a]=r[a])}return e},s.apply(this,arguments)}function n(e,t){var r=Object.keys(e);if(Object.getOwnPropertySymbols){var a=Object.getOwnPropertySymbols(e);t&&(a=a.filter(function(t){return Object.getOwnPropertyDescriptor(e,t).enumerable})),r.push.apply(r,a)}return r}function l(e){for(var t=1;t<arguments.length;t++){var r=null!=arguments[t]?arguments[t]:{};t%2?n(Object(r),!0).forEach(function(t){c(e,t,r[t])}):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(r)):n(Object(r)).forEach(function(t){Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(r,t))})}return e}function c(e,t,r){var a;return(t="symbol"==typeof(a=function(e,t){if("object"!=typeof e||!e)return e;var r=e[Symbol.toPrimitive];if(void 0!==r){var a=r.call(e,t);if("object"!=typeof a)return a;throw new TypeError("@@toPrimitive must return a primitive value.")}return("string"===t?String:Number)(e)}(t,"string"))?a:a+"")in e?Object.defineProperty(e,t,{value:r,enumerable:!0,configurable:!0,writable:!0}):e[t]=r,e}function d(t){return t&&t.map((t,r)=>e.createElement(t.tag,l({key:r},t.attr),d(t.child)))}function u(t){return r=>e.createElement(p,s({attr:l({},t.attr)},r),d(t.child))}function p(t){var n=r=>{var a,{attr:n,size:c,title:d}=t,u=i(t,o),p=c||r.size||"1em";return r.className&&(a=r.className),t.className&&(a=(a?a+" ":"")+t.className),e.createElement("svg",s({stroke:"currentColor",fill:"currentColor",strokeWidth:"0"},r.attr,n,u,{className:a,style:l(l({color:t.color||r.color},r.style),t.style),height:p,width:p,xmlns:"http://www.w3.org/2000/svg"}),d&&e.createElement("title",null,d),t.children)};return void 0!==a?e.createElement(a.Consumer,null,e=>n(e)):n(r)}let m,f,y,b={data:""},g=/(?:([\u0080-\uFFFF\w-%@]+) *:? *([^{;]+?);|([^;}{]*?) *{)|(}\s*)/g,h=/\/\*[^]*?\*\/|  +/g,v=/\n+/g,x=(e,t)=>{let r="",a="",o="";for(let i in e){let s=e[i];"@"==i[0]?"i"==i[1]?r=i+" "+s+";":a+="f"==i[1]?x(s,i):i+"{"+x(s,"k"==i[1]?"":t)+"}":"object"==typeof s?a+=x(s,t?t.replace(/([^,])+/g,e=>i.replace(/([^,]*:\S+\([^)]*\))|([^,])+/g,t=>/&/.test(t)?t.replace(/&/g,e):e?e+" "+t:t)):i):null!=s&&(i=/^--/.test(i)?i:i.replace(/[A-Z]/g,"-$&").toLowerCase(),o+=x.p?x.p(i,s):i+":"+s+";")}return r+(t&&o?t+"{"+o+"}":o)+a},w={},O=e=>{if("object"==typeof e){let t="";for(let r in e)t+=r+O(e[r]);return t}return e};function j(e){let t=this||{},r=e.call?e(t.p):e;return((e,t,r,a,o)=>{let i=O(e),s=w[i]||(w[i]=(e=>{let t=0,r=11;for(;t<e.length;)r=101*r+e.charCodeAt(t++)>>>0;return"go"+r})(i));if(!w[s]){let t=i!==e?e:(e=>{let t,r,a=[{}];for(;t=g.exec(e.replace(h,""));)t[4]?a.shift():t[3]?(r=t[3].replace(v," ").trim(),a.unshift(a[0][r]=a[0][r]||{})):a[0][t[1]]=t[2].replace(v," ").trim();return a[0]})(e);w[s]=x(o?{["@keyframes "+s]:t}:t,r?"":"."+s)}let n=r&&w.g?w.g:null;return r&&(w.g=w[s]),l=w[s],c=t,d=a,(u=n)?c.data=c.data.replace(u,l):-1===c.data.indexOf(l)&&(c.data=d?l+c.data:c.data+l),s;var l,c,d,u})(r.unshift?r.raw?((e,t,r)=>e.reduce((e,a,o)=>{let i=t[o];if(i&&i.call){let e=i(r),t=e&&e.props&&e.props.className||/^go/.test(e)&&e;i=t?"."+t:e&&"object"==typeof e?e.props?"":x(e,""):!1===e?"":e}return e+a+(null==i?"":i)},""))(r,[].slice.call(arguments,1),t.p):r.reduce((e,r)=>Object.assign(e,r&&r.call?r(t.p):r),{}):r,(a=t.target,"object"==typeof window?((a?a.querySelector("#_goober"):window._goober)||Object.assign((a||document.head).appendChild(document.createElement("style")),{innerHTML:" ",id:"_goober"})).firstChild:a||b),t.g,t.o,t.k);var a}j.bind({g:1});let E=j.bind({k:1});function k(e,t){let r=this||{};return function(){let t=arguments;return function a(o,i){let s=Object.assign({},o),n=s.className||a.className;r.p=Object.assign({theme:f&&f()},s),r.o=/ *go\d+/.test(n),s.className=j.apply(r,t)+(n?" "+n:"");let l=e;return e[0]&&(l=s.as||e,delete s.as),y&&l[0]&&y(s),m(l,s)}}}var P=(e,t)=>(e=>"function"==typeof e)(e)?e(t):e,C=(()=>{let e=0;return()=>(++e).toString()})(),$=(()=>{let e;return()=>{if(void 0===e&&typeof window<"u"){let t=matchMedia("(prefers-reduced-motion: reduce)");e=!t||t.matches}return e}})(),D="default",N=(e,t)=>{let{toastLimit:r}=e.settings;switch(t.type){case 0:return{...e,toasts:[t.toast,...e.toasts].slice(0,r)};case 1:return{...e,toasts:e.toasts.map(e=>e.id===t.toast.id?{...e,...t.toast}:e)};case 2:let{toast:a}=t;return N(e,{type:e.toasts.find(e=>e.id===a.id)?1:0,toast:a});case 3:let{toastId:o}=t;return{...e,toasts:e.toasts.map(e=>e.id===o||void 0===o?{...e,dismissed:!0,visible:!1}:e)};case 4:return void 0===t.toastId?{...e,toasts:[]}:{...e,toasts:e.toasts.filter(e=>e.id!==t.toastId)};case 5:return{...e,pausedAt:t.time};case 6:let i=t.time-(e.pausedAt||0);return{...e,pausedAt:void 0,toasts:e.toasts.map(e=>({...e,pauseDuration:e.pauseDuration+i}))}}},z=[],I={toasts:[],pausedAt:void 0,settings:{toastLimit:20}},A={},S=(e,t=D)=>{A[t]=N(A[t]||I,e),z.forEach(([e,r])=>{e===t&&r(A[t])})},T=e=>Object.keys(A).forEach(t=>S(e,t)),F=(e=D)=>t=>{S(t,e)},L={blank:4e3,error:4e3,success:2e3,loading:1/0,custom:4e3},M=e=>(t,r)=>{let a=((e,t="blank",r)=>({createdAt:Date.now(),visible:!0,dismissed:!1,type:t,ariaProps:{role:"status","aria-live":"polite"},message:e,pauseDuration:0,...r,id:(null==r?void 0:r.id)||C()}))(t,e,r);return F(a.toasterId||(e=>Object.keys(A).find(t=>A[t].toasts.some(t=>t.id===e)))(a.id))({type:2,toast:a}),a.id},H=(e,t)=>M("blank")(e,t);H.error=M("error"),H.success=M("success"),H.loading=M("loading"),H.custom=M("custom"),H.dismiss=(e,t)=>{let r={type:3,toastId:e};t?F(t)(r):T(r)},H.dismissAll=e=>H.dismiss(void 0,e),H.remove=(e,t)=>{let r={type:4,toastId:e};t?F(t)(r):T(r)},H.removeAll=e=>H.remove(void 0,e),H.promise=(e,t,r)=>{let a=H.loading(t.loading,{...r,...null==r?void 0:r.loading});return"function"==typeof e&&(e=e()),e.then(e=>{let o=t.success?P(t.success,e):void 0;return o?H.success(o,{id:a,...r,...null==r?void 0:r.success}):H.dismiss(a),e}).catch(e=>{let o=t.error?P(t.error,e):void 0;o?H.error(o,{id:a,...r,...null==r?void 0:r.error}):H.dismiss(a)}),e};var R,_,U,q,B=(e,r="default")=>{let{toasts:a,pausedAt:o}=((e={},r=D)=>{let[a,o]=t.useState(A[r]||I),i=t.useRef(A[r]);t.useEffect(()=>(i.current!==A[r]&&o(A[r]),z.push([r,o]),()=>{let e=z.findIndex(([e])=>e===r);e>-1&&z.splice(e,1)}),[r]);let s=a.toasts.map(t=>{var r,a,o;return{...e,...e[t.type],...t,removeDelay:t.removeDelay||(null==(r=e[t.type])?void 0:r.removeDelay)||(null==e?void 0:e.removeDelay),duration:t.duration||(null==(a=e[t.type])?void 0:a.duration)||(null==e?void 0:e.duration)||L[t.type],style:{...e.style,...null==(o=e[t.type])?void 0:o.style,...t.style}}});return{...a,toasts:s}})(e,r),i=t.useRef(new Map).current,s=t.useCallback((e,t=1e3)=>{if(i.has(e))return;let r=setTimeout(()=>{i.delete(e),n({type:4,toastId:e})},t);i.set(e,r)},[]);t.useEffect(()=>{if(o)return;let e=Date.now(),t=a.map(t=>{if(t.duration===1/0)return;let a=(t.duration||0)+t.pauseDuration-(e-t.createdAt);if(!(a<0))return setTimeout(()=>H.dismiss(t.id,r),a);t.visible&&H.dismiss(t.id)});return()=>{t.forEach(e=>e&&clearTimeout(e))}},[a,o,r]);let n=t.useCallback(F(r),[r]),l=t.useCallback(()=>{n({type:5,time:Date.now()})},[n]),c=t.useCallback((e,t)=>{n({type:1,toast:{id:e,height:t}})},[n]),d=t.useCallback(()=>{o&&n({type:6,time:Date.now()})},[o,n]),u=t.useCallback((e,t)=>{let{reverseOrder:r=!1,gutter:o=8,defaultPosition:i}=t||{},s=a.filter(t=>(t.position||i)===(e.position||i)&&t.height),n=s.findIndex(t=>t.id===e.id),l=s.filter((e,t)=>t<n&&e.visible).length;return s.filter(e=>e.visible).slice(...r?[l+1]:[0,l]).reduce((e,t)=>e+(t.height||0)+o,0)},[a]);return t.useEffect(()=>{a.forEach(e=>{if(e.dismissed)s(e.id,e.removeDelay);else{let t=i.get(e.id);t&&(clearTimeout(t),i.delete(e.id))}})},[a,s]),{toasts:a,handlers:{updateHeight:c,startPause:l,endPause:d,calculateOffset:u}}},G=E`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
 transform: scale(1) rotate(45deg);
  opacity: 1;
}`,W=E`
from {
  transform: scale(0);
  opacity: 0;
}
to {
  transform: scale(1);
  opacity: 1;
}`,Y=E`
from {
  transform: scale(0) rotate(90deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(90deg);
	opacity: 1;
}`,Z=k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#ff4b4b"};
  position: relative;
  transform: rotate(45deg);

  animation: ${G} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;

  &:after,
  &:before {
    content: '';
    animation: ${W} 0.15s ease-out forwards;
    animation-delay: 150ms;
    position: absolute;
    border-radius: 3px;
    opacity: 0;
    background: ${e=>e.secondary||"#fff"};
    bottom: 9px;
    left: 4px;
    height: 2px;
    width: 12px;
  }

  &:before {
    animation: ${Y} 0.15s ease-out forwards;
    animation-delay: 180ms;
    transform: rotate(90deg);
  }
`,J=E`
  from {
    transform: rotate(0deg);
  }
  to {
    transform: rotate(360deg);
  }
`,K=k("div")`
  width: 12px;
  height: 12px;
  box-sizing: border-box;
  border: 2px solid;
  border-radius: 100%;
  border-color: ${e=>e.secondary||"#e0e0e0"};
  border-right-color: ${e=>e.primary||"#616161"};
  animation: ${J} 1s linear infinite;
`,Q=E`
from {
  transform: scale(0) rotate(45deg);
	opacity: 0;
}
to {
  transform: scale(1) rotate(45deg);
	opacity: 1;
}`,V=E`
0% {
	height: 0;
	width: 0;
	opacity: 0;
}
40% {
  height: 0;
	width: 6px;
	opacity: 1;
}
100% {
  opacity: 1;
  height: 10px;
}`,X=k("div")`
  width: 20px;
  opacity: 0;
  height: 20px;
  border-radius: 10px;
  background: ${e=>e.primary||"#61d345"};
  position: relative;
  transform: rotate(45deg);

  animation: ${Q} 0.3s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
  animation-delay: 100ms;
  &:after {
    content: '';
    box-sizing: border-box;
    animation: ${V} 0.2s ease-out forwards;
    opacity: 0;
    animation-delay: 200ms;
    position: absolute;
    border-right: 2px solid;
    border-bottom: 2px solid;
    border-color: ${e=>e.secondary||"#fff"};
    bottom: 6px;
    left: 6px;
    height: 10px;
    width: 6px;
  }
`,ee=k("div")`
  position: absolute;
`,te=k("div")`
  position: relative;
  display: flex;
  justify-content: center;
  align-items: center;
  min-width: 20px;
  min-height: 20px;
`,re=E`
from {
  transform: scale(0.6);
  opacity: 0.4;
}
to {
  transform: scale(1);
  opacity: 1;
}`,ae=k("div")`
  position: relative;
  transform: scale(0.6);
  opacity: 0.4;
  min-width: 20px;
  animation: ${re} 0.3s 0.12s cubic-bezier(0.175, 0.885, 0.32, 1.275)
    forwards;
`,oe=({toast:e})=>{let{icon:r,type:a,iconTheme:o}=e;return void 0!==r?"string"==typeof r?t.createElement(ae,null,r):r:"blank"===a?null:t.createElement(te,null,t.createElement(K,{...o}),"loading"!==a&&t.createElement(ee,null,"error"===a?t.createElement(Z,{...o}):t.createElement(X,{...o})))},ie=e=>`\n0% {transform: translate3d(0,${-200*e}%,0) scale(.6); opacity:.5;}\n100% {transform: translate3d(0,0,0) scale(1); opacity:1;}\n`,se=e=>`\n0% {transform: translate3d(0,0,-1px) scale(1); opacity:1;}\n100% {transform: translate3d(0,${-150*e}%,-1px) scale(.6); opacity:0;}\n`,ne=k("div")`
  display: flex;
  align-items: center;
  background: #fff;
  color: #363636;
  line-height: 1.3;
  will-change: transform;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.1), 0 3px 3px rgba(0, 0, 0, 0.05);
  max-width: 350px;
  pointer-events: auto;
  padding: 8px 10px;
  border-radius: 8px;
`,le=k("div")`
  display: flex;
  justify-content: center;
  margin: 4px 10px;
  color: inherit;
  flex: 1 1 auto;
  white-space: pre-line;
`,ce=t.memo(({toast:e,position:r,style:a,children:o})=>{let i=e.height?((e,t)=>{let r=e.includes("top")?1:-1,[a,o]=$()?["0%{opacity:0;} 100%{opacity:1;}","0%{opacity:1;} 100%{opacity:0;}"]:[ie(r),se(r)];return{animation:t?`${E(a)} 0.35s cubic-bezier(.21,1.02,.73,1) forwards`:`${E(o)} 0.4s forwards cubic-bezier(.06,.71,.55,1)`}})(e.position||r||"top-center",e.visible):{opacity:0},s=t.createElement(oe,{toast:e}),n=t.createElement(le,{...e.ariaProps},P(e.message,e));return t.createElement(ne,{className:e.className,style:{...i,...a,...e.style}},"function"==typeof o?o({icon:s,message:n}):t.createElement(t.Fragment,null,s,n))});R=t.createElement,x.p=_,m=R,f=U,y=q;var de=({id:e,className:r,style:a,onHeightUpdate:o,children:i})=>{let s=t.useCallback(t=>{if(t){let r=()=>{let r=t.getBoundingClientRect().height;o(e,r)};r(),new MutationObserver(r).observe(t,{subtree:!0,childList:!0,characterData:!0})}},[e,o]);return t.createElement("div",{ref:s,className:r,style:a},i)},ue=j`
  z-index: 9999;
  > * {
    pointer-events: auto;
  }
`,pe=({reverseOrder:e,position:r="top-center",toastOptions:a,gutter:o,children:i,toasterId:s,containerStyle:n,containerClassName:l})=>{let{toasts:c,handlers:d}=B(a,s);return t.createElement("div",{"data-rht-toaster":s||"",style:{position:"fixed",zIndex:9999,top:16,left:16,right:16,bottom:16,pointerEvents:"none",...n},className:l,onMouseEnter:d.startPause,onMouseLeave:d.endPause},c.map(a=>{let s=a.position||r,n=((e,t)=>{let r=e.includes("top"),a=r?{top:0}:{bottom:0},o=e.includes("center")?{justifyContent:"center"}:e.includes("right")?{justifyContent:"flex-end"}:{};return{left:0,right:0,display:"flex",position:"absolute",transition:$()?void 0:"all 230ms cubic-bezier(.21,1.02,.73,1)",transform:`translateY(${t*(r?1:-1)}px)`,...a,...o}})(s,d.calculateOffset(a,{reverseOrder:e,gutter:o,defaultPosition:r}));return t.createElement(de,{id:a.id,key:a.id,onHeightUpdate:d.updateHeight,className:a.visible?ue:"",style:n},"custom"===a.type?P(a.message,a):i?i(a):t.createElement(ce,{toast:a,position:s}))}))};export{pe as F,u as G,H as n};
